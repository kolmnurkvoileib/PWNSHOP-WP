<footer>

<div class="footer">
<div class="footercontainer">

<div class="footerkontakt">
<h3>Kontakt info</h3>
<p>Jakobsoni 6</p>
<p><a href="tel:+372 5014769">+372 5014769</a></p>
<p><a href="mailto:kellapandimaja@tkepandimaja.ee">kellapandimaja@tkepandimaja.ee</a></p>
<p>ONLINE hindamine 24/7</p>
<p>Kontori lahtioleku ajad E-R 9-17</p>

</div>

<div class="footermuu">
<img src="//www.tkepandimaja.ee/img/kellalogo.png" alt="Kella_pandimaja" height="200" width="200"><br>
<?php echo date("Y"); ?>
</div>

<div class="footerinfo">
<h3>Ettevõtte info</h3>
<p>Esimene kella pandimaja Eestis</p>
<p>TKE Pandimaja OÜ asutati AS Tallinna pank, Karavan OÜ ja E.P.T.A. OÜ poolt 1992 aastal (sellest ka firma nimi TKE Pandimaja. Tänaseks on need juriidilised asutajaliikmed läinud igaüks oma teed, kuid juhtkond ja põhiline personal on säilinud. </p><p> Iseenda arvates oleme andnud parima oma klientide teenendamisel. Kuid kindlasti on veel palju arengumaad. Ja need maad me püüame lähitulevikus okupeerida.</p>
</div>

</div>

</div>

</footer>

<?php wp_footer(); ?>

</body>

</html>