<!doctype html>
<html>
  <script type="text/javascript">
var templateUrl = '<?php bloginfo('template_url'); ?>';
</script>
  <head>
                  <meta name="keywords" content="ruhnu lennugraafik, ruhnu töö, ruhnu lasteaed, Liise talu ruhnu, ruhnu talud, ruhnu sadam, ruhnu saare blogi, visit ruhnu, visitruhnu, visit,
    vallavalitsus, majutus, toitlustus, talutoit, talutoidud, käsitöö, nybon, vitali, liise talu, talu, kardon, puhkemajad, kirikud, bullersi, buldersi, Saun, Limo, puhkus, avatud, aastaringselt, tünnisaun, kamin, köök, grupile, grupp, gruppidele, rand, 
    meri, ruhnu, saar, traditsiooniline, ekskursioon, tuletorn, huvitav, roostiku, muuseum, kohvik, pood, korsi, ruhnuring, alkeemialabor">
       <meta name="description" content="Ruhnu saar asub Liivi lahe keskel. Liivi lahe kauneim saar Ruhnu asub kolme tunni laevasõidu kaugusel Pärnust ja kahe tunni laevasõidu kaugusel Saaremaalt. Lennukiga jõuate Pärnust ja Saaremaalt poole tunniga. Lähim maismaapunkt on 37 km kaugusel asuv Kolka neem Kuramaal Lätis. Kuressaarde on linnulennult 70 km, Kihnu saareni 54 km, Pärnu ja Riiga 96 km. Ruhnu saar on üks viiest Eesti saarvallast (Saaremaa, Hiiumaa, Muhu, Vormsi, Kihnu, Ruhnu) ja nendest kõige väiksem. 2020 aasta seisuga elab aastaringselt ainsas Ruhnu külas umbes 55 elanikku, kellest 10 on lapsed. Ületalve majapidamisi on kokku 30. Suviti lisandub kümmekond juurde, kellest osa on kunagiste ruhnurootslaste järeltulijad.">
 
    <meta charset="utf-8">
    <title>TKEPANDIMAJA BLOGI</title>
    <?php wp_head(); ?>
    
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
     <meta name="viewport" content="width=device-width, initial-scale=1">
     
     <link href="https://fonts.googleapis.com/css?family=Montserrat:200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">
     <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900&display=swap" rel="stylesheet">
     
    
    <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-166180590-1"></script>
<script>
$(document).ready(function() {
    if ($('#wpadminbar')[0]) {
        $('.navbg, .logo-nav').css('top', '32px')
    }
});


</script>


    
</head>

<div class="logo-nav">

<nav class="navbar navbar-expand-lg navbar-light">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-content" aria-controls="navbar-content" aria-expanded="false" aria-label="<?php esc_html_e( 'Toggle Navigation', 'theme-textdomain' ); ?>">
        <span class="navbar-toggler-icon"></span>
    </button>
 
    <div class="collapse navbar-collapse" id="navbar-content">
            <?php
        wp_nav_menu( array(
            'theme_location' => 'primary', // Defined when registering the menu
            'menu_id'        => 'primary-menu',
            'container'      => false,
            'depth'          => 2,
            'menu_class'     => 'navbar-nav mx-auto',
            'walker'         => new Bootstrap_NavWalker(), // This controls the display of the Bootstrap Navbar
            'fallback_cb'    => 'Bootstrap_NavWalker::fallback', // For menu fallback
        ) );
    
    
        ?>
    
    </div>
</nav>

</div>
<div class="navbg"></div>
<div class="custom-header">
  




<div class="title-tagline">

<h1 class="header-title"><span><?php bloginfo('name'); ?></span></h1>

</div>





</div>

<body>