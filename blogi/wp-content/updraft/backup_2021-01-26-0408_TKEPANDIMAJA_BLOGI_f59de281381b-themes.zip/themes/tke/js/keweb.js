
$(document).ready(function() {
    if ($('#wpadminbar')[0]) {
        $('.navbg, .logo-nav').css('top', '32px')
    }
});


